module.exports = require('requireindex')(__dirname + '/models');
